import { Component } from '@angular/core';
import { tipService } from '../tip-service';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { RouterLink } from '@angular/router';
import {DatePipe, DecimalPipe} from '@angular/common';

@Component({
  selector: 'app-output',
  standalone: true,
  imports: [
    MatCardModule,
    MatButtonModule,
    MatTableModule,
    RouterLink,
    DatePipe,
    DecimalPipe
  ],
  templateUrl: './output.html',
  styleUrls: ['./output.css']
})
export class Output {
  data = tipService.getInputData();

  displayedColumns: string[] = [
    'name',
    'cost',
    'serviceType',
    'qualityPercent',
    'roundUp',
    'date',
    'notes',
    'tipAmount',
    'totalAmount'
  ];

  dataSource = this.data ? [this.data] : [];

  get tipAmount() {
    return tipService.getTipAmount();
  }

  get totalAmount() {
    return tipService.getTotalAmount();
  }
}
